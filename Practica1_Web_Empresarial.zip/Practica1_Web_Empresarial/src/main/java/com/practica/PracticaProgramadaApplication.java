package com.practica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaProgramadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaProgramadaApplication.class, args);
	}

}
